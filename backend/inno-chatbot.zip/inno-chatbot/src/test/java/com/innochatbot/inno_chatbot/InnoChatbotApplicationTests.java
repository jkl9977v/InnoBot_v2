package com.innochatbot.inno_chatbot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InnoChatbotApplicationTests {

	@Test
	void contextLoads() {
	}

}
